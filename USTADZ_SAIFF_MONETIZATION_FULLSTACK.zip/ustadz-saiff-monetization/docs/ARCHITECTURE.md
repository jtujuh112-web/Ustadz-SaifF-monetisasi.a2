# Arsitektur dan keamanan

## Sumber data
- Profiles: role/status/plan/quota. Akun otomatis dibuat oleh trigger `auth.users`; browser hanya SELECT profilnya sendiri; tidak ada policy UPDATE anggota. Perubahan role manual SQL oleh operator, perubahan status/kuota lewat admin server.
- Projects: source, settings JSON, manifest path, 5 concepts, selected concept, storyboard, favorite. RLS hanya user_id = auth.uid().
- Generation logs: status, token, model, estimasi cost; member READ log sendiri; WRITE hanya server role.
- app_settings: global katalog/limit JSON; member READ, admin POST melalui API yang memverifikasi role.
- Storage: bucket private; path `userId/file...` dan policy RLS untuk SELECT/INSERT/DELETE oleh pemilik.

## Auth
- Frontend menyimpan sesi dengan SDK Supabase; API memerlukan access token Bearer.
- Server memakai `adminDB.auth.getUser(token)` sehingga tidak percaya user_id yang dikirim client.
- Semua request AI menjalankan `claim_generation` secara atomik: lock row profil, periksa active status, reset kuota per bulan UTC, rate limit 5/menit, dan update counter.
- Setelah provider sukses, `finish_generation` menyimpan token dan status; pada exception counter dikembalikan.
- `service_role` hanya dipakai dalam Next.js server routes, **jangan pernah masukkan ke Next_PUBLIC**.

## Prompt pipeline
1. `settingsSchema` memvalidasi ide/durasi (durations.length = sceneCount) dan karakter.
2. `ideasSchema` mewajibkan tepat 5 ide.
3. `storyboardSchema` mewajibkan semua field, jumlah scene, durasi, jumlah dan durasi shot; JSON provider tidak valid diberi 1 percobaan perbaikan.
4. Scene regeneration memodifikasi hanya indeks target; lock scene dicek di UI. Untuk keamanan tambahan bisa simpan lock di database dan validasi dari backend.
5. AI mengembalikan Quality score heuristik dan reasons; tidak dianggap sertifikasi konsistensi gambar/video oleh target.

## ATM video
- Browser mengambil 4 keyframe; AI vision menginterpretasi frame, bukan seluruh video/audio. Metadata dihitung dari file lokal.
- Video asli disimpan di private storage saat analisis, tetapi tidak diteruskan ke OpenAI sebagai file video. Hanya JPEG frame terkirim setelah consent.
- Pengguna mengedit ringkasan dan memilih pola yang diperbolehkan sebelum membuat cerita baru.

## Render model
- UI tidak memiliki tombol Generate Video. `videoApi:false` untuk semua preset. Menambahkan render API akan butuh adapter resmi, storage output, queue, polling, penagihan dan vendor auth.
- Verified berarti rilis/kondisi model diketahui dari referensi resmi, **bukan** berarti akun Anda telah mendapatkan API akses atau semua fitur didukung.
