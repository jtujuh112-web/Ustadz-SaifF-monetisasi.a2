# Smoke tests

1. `npm install && npm run typecheck && npm run build`.
2. Tanpa env, buka `/` dan `/api/health`, pastikan jelas tertulis belum terhubung.
3. Dengan env + migrasi: login, upload karakter, analisis, hapus. Pantau storage private.
4. Generate 5 konsep, cek jumlah persis 5. Pilih konsep, scene 4 x 12 detik dan Veo 3.1; tiap scene harus punya 2 shot <=8 detik (6+6).
5. Edit dan kunci scene, regenerate scene lain, diff output json sebelum dan sesudah.
6. Export TXT/JSON/PDF, simpan proyek, kembali lewat Riwayat, favoriti, duplikat.
7. ATM video MP4 di bawah 50MB dan 120s, 4 frame diekstrak; laporkan keterbatasan analisis frame.
8. Admin: set member suspended, GET/POST `/api/ai` sebagai member harus ditolak, role admin tidak bisa diganti dari browser.
9. Security: POST `/api/ai` tanpa Bearer token -> 401, terlalu banyak request -> 429, kuota habis -> 429; tidak ada API key frontend.
10. Safari iOS / Chrome Android: keyboard, sticky nav, upload dari galeri, clipboard, download file.
