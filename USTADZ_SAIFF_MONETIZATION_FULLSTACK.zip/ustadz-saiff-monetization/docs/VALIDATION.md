# Validasi — 8 November 2026

## Sudah dijalankan
- `NODE_PATH=... npm run test:source` pada lingkungan pembuatan: **PASS**.
- 18 file TypeScript/TSX: tidak ada error parsing saat transpile.
- Fungsi `shotDurations`: 10/8 → [5,5], 12/8 → [6,6], 15/8 → [8,7], 15/15 → [15], 12/null → [12].
- `modelProfile`: Veo 3.1 memberi peringatan 8 detik; Seedance 2.0 tidak memperingatkan durasi 12 detik.
- Audit manual: API keys hanya dibaca pada server; `service_role` hanya di route server.

## Belum dijalankan
- `npm install`, `npm run typecheck` dengan dependensi sesungguhnya, `npm run build`.
- Uji integrasi Supabase Auth, SQL/RLS, upload dan AI provider berbayar.
- Uji perangkat Android/iOS, PDF, beban 20 scene, latensi provider, dan keamanan end-to-end.
- Deploy Vercel produksi: memerlukan akun dan konfigurasi pengguna.

## Kondisi siap produksi
Aplikasi harus lulus semua tes yang belum dijalankan, memiliki monitoring, kebijakan privasi final, batas biaya API nyata, rate limit pada infrastruktur, moderation, backup, dan penanganan error/log yang diaudit. Jangan menganggap ZIP yang belum di-deploy sebagai situs publik aktif.
