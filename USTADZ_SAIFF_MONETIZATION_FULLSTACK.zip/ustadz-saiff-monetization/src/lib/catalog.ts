export const DEFAULT_CATEGORIES = ["Islami dan motivasi","Kisah inspiratif","Cerita sedih dan emosional","Komedi dan humor","Hewan lucu","Hewan realistis","Hewan antropomorfik","Petualangan","Fantasi","Horor","Misteri","Edukasi","Fakta unik","Sejarah","Animasi anak","Kartun keluarga","Kehidupan sehari-hari","Drama keluarga","Persahabatan","Cerita perjuangan","Konten tanpa wajah","Konten cinematic","Konten ASMR","Mini movie","Storytelling viral","Iklan produk","Konten affiliate","Konten motivasi bisnis","Custom"];
export const DEFAULT_STYLES = ["Stickman 2D","Stickman 3D","Clay animation","Claymation","Stop motion","2D cartoon","3D cartoon","Anime","Chibi","Pixel art","Low poly","Paper cut animation","Watercolor","Comic book","Doodle animation","Whiteboard animation","Photorealistic","Hyperrealistic","Cinematic realistic","Miniature world","Diorama","Felt / wool animation","Plush toy","LEGO-like block animation","Silhouette","Dark fantasy","Surreal","Vintage film","Documentary","POV","Macro cinematic","Custom"];
export const STYLE_ICONS = ["✎","♙","🧱","🎨","🎞","🌈","🎭","🌸","🍡","👾","🔺","✂️","🖌","💥","✏️","📝","📷","✨","🎬","🏡","🏞","🧶","🧸","🧩","🌘","🌑","🌀","📼","🎥","👁","🔍","⚡"];
export const LANGUAGES = ["Bahasa Indonesia","Bahasa Inggris","Bahasa Arab","Bahasa Melayu","Bahasa Jepang","Bahasa Korea","Bahasa Mandarin","Bahasa Spanyol","Bahasa lainnya (custom)"];
export const AUDIO_MODES = ["Tanpa dialog","Narasi saja","Dialog karakter","Voice-over","Suara hewan alami","Suara hewan yang berbicara","ASMR / ambience","Musik dan sound effects saja","Tanpa audio"];
export const LOCATIONS = ["Otomatis sesuai ide","Pedesaan Indonesia","Perkotaan modern","Hutan tropis","Pegunungan","Pantai","Gurun pasir","Masjid","Pesantren","Sekolah","Rumah sederhana","Rumah mewah","Pasar tradisional","Jalanan kota","Kerajaan fantasi","Luar angkasa","Dunia miniatur","Studio","Custom"];
export const MOODS = ["Emosional","Inspiratif","Hangat","Lucu","Tegang","Misterius","Tenang","Epik","Mengharukan","Optimistis"];
export const CAMERA = ["Otomatis sinematik","Static wide","Slow push-in","Tracking","Dolly","Handheld","Orbit","Crane","POV","Macro"];
export const ASPECTS = ["9:16","16:9","1:1","4:5","3:4","Custom"];
export type ModelPreset = { id:string; name:string; status:"verified"|"experimental"|"retired"; maxClipSeconds:number|null; detail:string; aspectRatios?:string[]; videoApi:boolean };
export const DEFAULT_MODELS:ModelPreset[] = [
 {id:"seedance",name:"Seedance (umum)",status:"experimental",maxClipSeconds:null,detail:"Versi belum ditentukan; cek kemampuan layanan tujuan.",videoApi:false},
 {id:"seedance-2",name:"Seedance 2.0",status:"verified",maxClipSeconds:15,detail:"Model resmi; akses API melalui penyedia yang kompatibel perlu dikonfigurasi.",videoApi:false},
 {id:"seedance-25",name:"Seedance 2.5",status:"verified",maxClipSeconds:30,detail:"Resmi diumumkan ByteDance; ketersediaan API tergantung penyedia.",videoApi:false},
 {id:"veo-31",name:"Google Veo 3.1",status:"verified",maxClipSeconds:8,detail:"Klip 4/6/8 detik; 10–15 detik perlu dibagi ke beberapa shot.",aspectRatios:["9:16","16:9"],videoApi:false},
 {id:"muse",name:"Muse AI / Muse Video",status:"experimental",maxClipSeconds:null,detail:"Nama produk dan model spesifik perlu dipilih; belum terintegrasi.",videoApi:false},
 {id:"kling",name:"Kling AI",status:"experimental",maxClipSeconds:null,detail:"Kemampuan bergantung model dan paket yang dipakai.",videoApi:false},
 {id:"runway",name:"Runway",status:"experimental",maxClipSeconds:null,detail:"Pilih versi model pada layanan tujuan.",videoApi:false},
 {id:"pika",name:"Pika",status:"experimental",maxClipSeconds:null,detail:"Kemampuan perlu dicek menurut versi.",videoApi:false},
 {id:"luma",name:"Luma",status:"experimental",maxClipSeconds:null,detail:"Kemampuan perlu dicek menurut versi.",videoApi:false},
 {id:"sora",name:"Sora (API dihentikan)",status:"retired",maxClipSeconds:null,detail:"API Sora ditutup pada 24 September 2026. Preset hanya untuk arsip, tidak tersedia untuk generate.",videoApi:false},
 {id:"other",name:"Model AI lainnya",status:"experimental",maxClipSeconds:null,detail:"Tulis nama model yang ingin dituju.",videoApi:false},
 {id:"custom",name:"Custom model",status:"experimental",maxClipSeconds:null,detail:"Anda bertanggung jawab memverifikasi dukungan model.",videoApi:false}
];
export const DEFAULT_SETTINGS = { categories:DEFAULT_CATEGORIES,styles:DEFAULT_STYLES,models:DEFAULT_MODELS,maxImages:10,maxImageMB:10,maxVideoMB:50,maxVideoSeconds:120 };
