import { z } from "zod";
import { DEFAULT_MODELS, type ModelPreset } from "./catalog";
import type { StudioSettings, Concept, Storyboard } from "./schemas";

export type AIMessage={role:"system"|"user"|"assistant";content:string|Array<{type:"text";text:string}|{type:"image_url";image_url:{url:string;detail?:"low"|"high"}}>} ;
export type TokenUsage={input:number;output:number};
export type AIResult<T>={value:T;usage:TokenUsage;model:string};
export async function callAI<T>(messages:AIMessage[],schema:z.ZodType<T>,isVision=false,maxOutputTokens=6000):Promise<AIResult<T>>{
 const apiKey=process.env.OPENAI_API_KEY;
 if(!apiKey||apiKey.startsWith("YOUR_")) throw new Error("OPENAI_API_KEY belum dipasang. Hubungkan AI pada pengaturan server.");
 const model=(isVision?process.env.AI_VISION_MODEL:process.env.AI_TEXT_MODEL)||"gpt-4.1-mini";
 let totalInput=0,totalOutput=0;
 let repair="";
 for(let attempt=0;attempt<2;attempt++){
  const res=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${apiKey}`,"Content-Type":"application/json"},body:JSON.stringify({model,temperature:0.65,max_completion_tokens:maxOutputTokens,response_format:{type:"json_object"},messages:[...messages,...(repair?[{role:"user",content:repair}]:[])]}),signal:AbortSignal.timeout(90000),cache:"no-store"});
  const data=await res.json().catch(()=>({}));
  if(!res.ok){const reason=typeof data?.error?.message==="string"?data.error.message:`HTTP ${res.status}`;throw new Error(`AI provider: ${reason.slice(0,300)}`);}
  totalInput+=data?.usage?.prompt_tokens||0;totalOutput+=data?.usage?.completion_tokens||0;
  const raw=data?.choices?.[0]?.message?.content;
  try{if(typeof raw!=="string")throw new Error("AI mengembalikan respons kosong");const parsed=JSON.parse(raw);const checked=schema.safeParse(parsed);if(checked.success)return {value:checked.data,usage:{input:totalInput,output:totalOutput},model};repair=`JSON sebelumnya tidak sesuai schema: ${checked.error.issues.slice(0,6).map(x=>x.path.join(".")+": "+x.message).join("; ")}. Kembalikan SATU objek JSON lengkap dan valid, tanpa penjelasan.`;}
  catch(e){repair=`Respons bukan JSON yang valid: ${String(e).slice(0,250)}. Kembalikan objek JSON lengkap dan valid tanpa penjelasan.`;}
 }
 throw new Error("AI belum menghasilkan JSON sesuai schema setelah validasi. Silakan coba ulang.");
}
export function modelProfile(settings:StudioSettings,models:ModelPreset[]=DEFAULT_MODELS){
 const entry=models.find(x=>x.id===settings.modelId)||DEFAULT_MODELS.find(x=>x.id==="custom")!;
 const target=(settings.modelId==="other"||settings.modelId==="custom")?settings.customModel||entry.name:entry.name;
 let plan="";
 const limit=entry.maxClipSeconds;
 if(limit!==null&&settings.durations.some(n=>n>limit)) plan=`Batas klip terverifikasi untuk ${target} adalah ${limit} detik. Pecah setiap scene editorial menjadi beberapa shot video mandiri dengan durasi tidak melebihi ${limit} detik. Durasi scene editorial tetap seperti pengaturan.`;
 if(entry.aspectRatios&&!entry.aspectRatios.includes(settings.aspect))plan+=` Rasio ${settings.aspect} tidak termasuk rasio terverifikasi; gunakan rasio yang kompatibel dan cropping saat editing.`;
 return {target,entry,plan};
}
export function describeSettings(v:StudioSettings,models:ModelPreset[]=DEFAULT_MODELS){
 const {target,entry,plan}=modelProfile(v,models);
 return JSON.stringify({originalIdea:v.idea,mustPreserveCoreIdea:true,extraInstructions:v.instructions,category:v.category,style:v.style,mood:v.mood,targetAudience:v.audience,message:v.message,purpose:v.purpose,language:v.language,customLanguage:v.customLanguage,audioMode:v.audio,voice:v.voice,voiceEmotion:v.voiceEmotion,speechTempo:v.speechTempo,subtitles:v.subtitles,location:v.location,time:v.time,weather:v.weather,lighting:v.lighting,sceneCount:v.sceneCount,durations:v.durations,shot:v.shot,camera:v.camera,transition:v.transition,pace:v.pace,storyArc:v.storyArc,aspect:v.aspect,customAspect:v.customAspect,resolutionTarget:v.resolution,targetVideoModel:target,presetStatus:entry.status,modelCaveat:plan,referenceCharacters:v.characters.map(({id,name,role,description})=>({id,name,role,description})),referenceTechniqueOnly:v.atmSummary||"none"});
}
export const systemBase=`Anda adalah sutradara dan prompt engineer video profesional. Selalu kembalikan SATU JSON object valid saja (tanpa markdown). Utamakan ide awal pengguna, jangan mengubah premis, identitas, tujuan atau pesan inti tanpa izin. Konten harus orisinal. Jangan meniru identitas orang atau materi berhak cipta dari referensi. Jangan mengklaim pasti viral. Jika pengguna memilih suara hewan alami, hewan hanya bersuara sesuai spesies. Jika tanpa dialog atau tanpa audio, jangan buat percakapan. Scene 10-15 detik berisi aksi terbatas dan dialog singkat. Semua prompt model video ditulis dalam bahasa Inggris yang jelas, sedangkan keterangan pengguna dan dialog sesuai bahasa yang dipilih. Negative prompt hanya jika relevan. Jangan menyatakan dukungan teknis yang belum diverifikasi.`;
export function shotDurations(duration:number,maxClip:number|null){
 if(!maxClip||duration<=maxClip)return [duration];
 const n=Math.ceil(duration/maxClip);const base=Math.floor(duration/n);return Array.from({length:n},(_,i)=>base+(i<duration%n?1:0));
}
export function formatFullPrompt(story:Storyboard,settings:StudioSettings){
 const {target,plan}=modelProfile(settings);
 return [`USTADZ SAIFF MONETIZATION`, `TARGET: ${target}`, `IDE: ${settings.idea}`, `FORMAT: ${settings.aspect} | ${settings.resolution}`,`DURATION: ${settings.durations.reduce((a,b)=>a+b,0)} sec`,plan,`\n=== CHARACTER BIBLE ===\n${story.characterBible}`,`\n=== STYLE BIBLE ===\n${story.styleBible}`,`\n=== MASTER PROMPT ===\n${story.masterPrompt}`, ...story.scenes.map((s,i)=>`\n=== SCENE ${i+1} — ${s.title} (${s.duration}s) ===\n${s.prompt}\n${s.shots.map((sh,j)=>`SHOT ${j+1} (${sh.duration}s): ${sh.prompt}`).join("\n")}\nCONTINUITY: ${s.continuity}\nDIALOGUE: ${s.dialogue}\nAUDIO: ${s.ambience}; ${s.sfx}\nNEGATIVE: ${s.negativePrompt}`)].filter(Boolean).join("\n");
}
export function chosenToText(c:Concept){return JSON.stringify(c);}
