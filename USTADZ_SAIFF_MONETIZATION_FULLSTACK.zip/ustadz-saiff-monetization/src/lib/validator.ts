import type { StudioSettings,Storyboard } from "./schemas";
import { modelProfile } from "./ai";
import { DEFAULT_MODELS,type ModelPreset } from "./catalog";
export type ValidationIssue={level:"warning"|"error";text:string};
export function auditStoryboard(story:Storyboard,settings:StudioSettings,models:ModelPreset[]=DEFAULT_MODELS):ValidationIssue[]{
 const issues:ValidationIssue[]=[];
 if(story.scenes.length!==settings.sceneCount)issues.push({level:"error",text:`Jumlah scene ${story.scenes.length} berbeda dari pengaturan ${settings.sceneCount}.`});
 const {entry}=modelProfile(settings,models);
 story.scenes.forEach((scene,i)=>{
  if(scene.duration!==settings.durations[i])issues.push({level:"error",text:`Scene ${i+1}: durasi berbeda dari pengaturan.`});
  if(scene.shots.reduce((a,s)=>a+s.duration,0)!==scene.duration)issues.push({level:"error",text:`Scene ${i+1}: total durasi shot tidak sesuai.`});
  if(entry.maxClipSeconds&&scene.shots.some(x=>x.duration>entry.maxClipSeconds!))issues.push({level:"error",text:`Scene ${i+1}: shot melebihi batas ${entry.maxClipSeconds} detik.`});
  if(scene.prompt.length<100)issues.push({level:"warning",text:`Scene ${i+1}: prompt utama relatif singkat, tinjau detail gerakan dan visual.`});
  if(settings.audio==="Tanpa audio"&&scene.dialogue.trim()&&!/^(none|no dialogue|silent|tanpa|tidak ada|n\/a|—|-)$/i.test(scene.dialogue.trim()))issues.push({level:"warning",text:`Scene ${i+1}: dialog terisi walaupun mode tanpa audio.`});
  if(settings.audio==="Tanpa dialog"&&scene.dialogue.trim()&&!/^(none|no dialogue|silent|tanpa|tidak ada|n\/a|—|-)$/i.test(scene.dialogue.trim()))issues.push({level:"warning",text:`Scene ${i+1}: dialog terisi walaupun mode tanpa dialog.`});
  if(!scene.continuity.trim())issues.push({level:"warning",text:`Scene ${i+1}: tidak ada catatan continuity.`});
 });
 if(entry.aspectRatios&&!entry.aspectRatios.includes(settings.aspect))issues.push({level:"warning",text:`Model ${entry.name} tidak terverifikasi mendukung rasio ${settings.aspect}.`});
 for(const c of settings.characters){if(!story.characterBible.toLowerCase().includes(c.name.toLowerCase()))issues.push({level:"warning",text:`Character Bible mungkin tidak menyebut karakter “${c.name}”.`});}
 return issues;
}
