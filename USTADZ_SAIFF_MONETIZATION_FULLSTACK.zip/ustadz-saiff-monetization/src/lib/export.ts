import type { StudioSettings,Storyboard } from "./schemas";
import { formatFullPrompt } from "./ai";
export function downloadBlob(blob:Blob,name:string){const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
export function exportTxt(s:Storyboard,v:StudioSettings){downloadBlob(new Blob([formatFullPrompt(s,v)],{type:"text/plain;charset=utf-8"}),"saiff-prompts.txt");}
export function exportJson(s:Storyboard,v:StudioSettings){downloadBlob(new Blob([JSON.stringify({settings:v,storyboard:s},null,2)],{type:"application/json"}),"saiff-storyboard.json");}
export async function exportPdf(s:Storyboard,v:StudioSettings){
 const {jsPDF}=await import("jspdf");const doc=new jsPDF({unit:"mm",format:"a4"});doc.setFont("helvetica");const width=180,margin=15;let y=18;
 function paragraph(t:string,head=false){const lines=doc.splitTextToSize(t.replace(/[^\x20-\x7E\n]/g," "),width) as string[];doc.setFontSize(head?13:9);if(head)doc.setFont("helvetica","bold");else doc.setFont("helvetica","normal");for(const line of lines){if(y>278){doc.addPage();y=18;}doc.text(line,margin,y);y+=head?7:4.7;}y+=4;}
 paragraph("USTADZ SAIFF MONETIZATION",true);paragraph("VIDEO PROMPT STORYBOARD");paragraph(`Source idea: ${v.idea}`);paragraph(`Target: ${v.modelId} | Format: ${v.aspect} | Duration: ${v.durations.reduce((a,b)=>a+b,0)} seconds`);paragraph("CHARACTER BIBLE",true);paragraph(s.characterBible);paragraph("STYLE BIBLE",true);paragraph(s.styleBible);paragraph("MASTER PROMPT",true);paragraph(s.masterPrompt);
 s.scenes.forEach((scene,i)=>{paragraph(`SCENE ${i+1}: ${scene.title} (${scene.duration}s)`,true);paragraph(scene.prompt);scene.shots.forEach((shot,j)=>{paragraph(`Shot ${j+1} (${shot.duration}s)`,true);paragraph(shot.prompt)});paragraph(`Continuity: ${scene.continuity}`);paragraph(`Audio: ${scene.ambience} | ${scene.sfx}`);});
 doc.save("saiff-storyboard.pdf");
}
