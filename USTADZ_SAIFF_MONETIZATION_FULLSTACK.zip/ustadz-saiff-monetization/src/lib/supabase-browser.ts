"use client";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
let instance:SupabaseClient|null=null;
export const hasSupabase=!!(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY && !process.env.NEXT_PUBLIC_SUPABASE_URL.includes("YOUR-PROJECT"));
export function getBrowserSupabase(){
 if(!hasSupabase) return null;
 if(!instance) instance=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
 return instance;
}
