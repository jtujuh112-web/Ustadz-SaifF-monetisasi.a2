import { createClient } from "@supabase/supabase-js";
import type { NextRequest } from "next/server";
export function adminDB() {
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL;
 const key=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!url||!key||url.includes("YOUR-PROJECT")) throw new Error("Supabase belum dikonfigurasi di server.");
 return createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
}
export async function authenticatedUser(req:NextRequest){
 const token=req.headers.get("authorization")?.match(/^Bearer (.+)$/i)?.[1];
 if(!token) throw new Error("AUTH_REQUIRED");
 const db=adminDB();
 const {data,error}=await db.auth.getUser(token);
 if(error||!data.user) throw new Error("AUTH_REQUIRED");
 const {data:profile,error:pError}=await db.from("profiles").select("id,role,membership,monthly_quota,quota_used,quota_month,plan").eq("id",data.user.id).single();
 if(pError||!profile) throw new Error("PROFILE_NOT_FOUND");
 return {db,user:data.user,profile};
}
