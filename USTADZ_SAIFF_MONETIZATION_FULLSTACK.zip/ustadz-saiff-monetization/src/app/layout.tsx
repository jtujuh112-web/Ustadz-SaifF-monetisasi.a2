import type { Metadata, Viewport } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Ustadz Saiff Monetization — AI Video Prompt Studio",
  description: "Ubah ide menjadi lima konsep konten dan storyboard AI video per scene, dengan karakter konsisten.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#071412" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
