import Link from "next/link";
export default function NotFound(){return <main className="mx-auto max-w-xl px-5 py-28 text-center"><h1 className="text-5xl font-black text-goldx">404</h1><p className="mt-4 text-mutedx">Halaman yang Anda cari tidak ditemukan.</p><Link className="primary mt-6" href="/">Kembali ke Studio</Link></main>}
