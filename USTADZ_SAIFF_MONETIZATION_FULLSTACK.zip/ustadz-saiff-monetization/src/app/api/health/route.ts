import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "Ustadz Saiff Monetization", supabaseConfigured: !!(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY), aiConfigured: !!process.env.OPENAI_API_KEY, mode: "prompt-generator-only" });
}
