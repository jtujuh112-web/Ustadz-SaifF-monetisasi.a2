import { NextRequest,NextResponse } from "next/server";
import { z } from "zod";
import { authenticatedUser } from "@/lib/auth";
import { DEFAULT_SETTINGS } from "@/lib/catalog";
export const runtime="nodejs";
const model=z.object({id:z.string().min(1).max(80),name:z.string().min(1).max(120),status:z.enum(["verified","experimental","retired"]),maxClipSeconds:z.number().min(1).max(120).nullable(),detail:z.string().max(400),aspectRatios:z.array(z.string()).optional(),videoApi:z.literal(false)});
const appSettings=z.object({categories:z.array(z.string().min(1).max(100)).min(1).max(100),styles:z.array(z.string().min(1).max(100)).min(1).max(100),models:z.array(model).min(1).max(100),maxImages:z.number().int().min(1).max(10),maxImageMB:z.number().int().min(1).max(10),maxVideoMB:z.number().int().min(1).max(50),maxVideoSeconds:z.number().int().min(10).max(120)});
async function verify(req:NextRequest){const auth=await authenticatedUser(req);if(auth.profile.role!=="admin")throw new Error("FORBIDDEN");return auth;}
function fail(e:unknown){const m=e instanceof Error?e.message:"Gagal";return NextResponse.json({error:m},{status:m==="FORBIDDEN"?403:m==="AUTH_REQUIRED"?401:500});}
export async function GET(req:NextRequest){try{const {db}=await verify(req);const [profiles,logs,settings]=await Promise.all([db.from("profiles").select("id,email,display_name,role,membership,monthly_quota,quota_used,quota_month,plan,created_at").order("created_at",{ascending:false}).limit(200),db.from("generation_logs").select("id,user_id,operation,model,status,input_tokens,output_tokens,estimated_cost_usd,created_at").order("created_at",{ascending:false}).limit(100),db.from("app_settings").select("data").eq("id","global").single()]);if(profiles.error||logs.error||settings.error)throw new Error(profiles.error?.message||logs.error?.message||settings.error?.message);return NextResponse.json({profiles:profiles.data,logs:logs.data,settings:{...DEFAULT_SETTINGS,...(settings.data?.data||{})}});}catch(e){return fail(e);}}
export async function POST(req:NextRequest){try{const {db,user}=await verify(req);const body=await req.json();if(body.kind==="member"){
 const val=z.object({kind:z.literal("member"),id:z.string().uuid(),membership:z.enum(["active","suspended"]),monthly_quota:z.number().int().min(0).max(100000),plan:z.string().max(50)}).parse(body);
 if(val.id===user.id&&val.membership==="suspended")throw new Error("Admin tidak dapat menonaktifkan akunnya sendiri.");
 const {error}=await db.from("profiles").update({membership:val.membership,monthly_quota:val.monthly_quota,plan:val.plan}).eq("id",val.id);if(error)throw error;return NextResponse.json({ok:true});
 }else if(body.kind==="settings"){
  const val=appSettings.parse(body.data);const {error}=await db.from("app_settings").upsert({id:"global",data:val,updated_at:new Date().toISOString()});if(error)throw error;return NextResponse.json({ok:true,settings:val});
 }return NextResponse.json({error:"Aksi admin tidak dikenal"},{status:400});}catch(e){return fail(e);}}
