import { NextRequest,NextResponse } from "next/server";
import { z } from "zod";
import { authenticatedUser } from "@/lib/auth";
import { DEFAULT_MODELS } from "@/lib/catalog";
import { callAI,systemBase,describeSettings,modelProfile,shotDurations,type AIMessage } from "@/lib/ai";
import { settingsSchema,ideasSchema,conceptSchema,storyboardSchema,sceneSchema,analysisSchema } from "@/lib/schemas";

export const runtime="nodejs";
export const maxDuration=120;
const baseRequest=z.object({action:z.enum(["suggest","ideas","storyboard","scene","characters","atm","recommend"]),settings:settingsSchema.optional(),concept:conceptSchema.optional(),storyboard:storyboardSchema.optional(),sceneIndex:z.number().int().min(0).max(19).optional(),characters:z.array(z.object({id:z.string(),path:z.string(),name:z.string(),role:z.string()})).max(10).optional(),frames:z.array(z.string().max(900000)).max(5).optional(),atmDuration:z.number().max(120).optional(),analysisNotes:z.string().max(4000).optional()});
function err(message:string,status=400){return NextResponse.json({error:message},{status});}
export async function POST(req:NextRequest){
 try{
  const contentLength=Number(req.headers.get("content-length")||0);
  if(contentLength>4800000)return err("Payload melebihi 4.8 MB",413);
  const {db,user,profile}=await authenticatedUser(req);
  if(profile.membership!=="active")return err("Akun sedang tidak aktif.",403);
  const bodyText=await req.text();
  if(new TextEncoder().encode(bodyText).length>4800000)return err("Payload melebihi 4.8 MB",413);
  const parsed=baseRequest.safeParse(JSON.parse(bodyText));
  if(!parsed.success)return err(`Input tidak valid: ${parsed.error.issues.slice(0,3).map(x=>x.path.join(".")+": "+x.message).join("; ")}`);
  const p=parsed.data;
  const {data:globalConfig}=await db.from("app_settings").select("data").eq("id","global").single();
  const presetModels=Array.isArray(globalConfig?.data?.models)?globalConfig.data.models:DEFAULT_MODELS;
  const action=p.action;
  if(["ideas","storyboard","scene","recommend"].includes(action)&&!p.settings)return err("Pengaturan ide diperlukan.");
  if(action==="storyboard"&&!p.concept)return err("Pilih satu konsep sebelum membuat storyboard.");
  if(action==="scene"&&(!p.storyboard||p.sceneIndex===undefined||!p.concept))return err("Scene, konsep, dan storyboard diperlukan.");
  if(action==="characters"&&(!p.characters||!p.characters.length))return err("Pilih gambar karakter yang telah diunggah.");
  if(action==="atm"&&(!p.frames||p.frames.length<2||!p.frames.every(x=>/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(x))))return err("Diperlukan minimal 2 keyframe video yang valid.");
  if(action==="atm"&&(p.atmDuration||0)>120)return err("Video maksimal 120 detik.");
  const model=(action==="characters"||action==="atm")?(process.env.AI_VISION_MODEL||"gpt-4.1-mini"):(process.env.AI_TEXT_MODEL||"gpt-4.1-mini");
  const claim=await db.rpc("claim_generation",{p_user:user.id,p_operation:action,p_model:model});
  if(claim.error){const msg=claim.error.message;return err(msg.includes("quota_exceeded")?"Kuota bulanan habis. Hubungi admin.":msg.includes("rate_limited")?"Terlalu banyak permintaan. Coba lagi setelah satu menit.":`Akses generate ditolak: ${msg}`,429);}
  const logId=claim.data as string;
  try{
   const common:AIMessage={role:"system",content:systemBase};
   let result:{value:unknown;usage:{input:number;output:number};model:string};
   if(action==="suggest"){
    result=await callAI([common,{role:"user",content:'Buat satu ide pendek konten video dalam bahasa Indonesia, kreatif, original, siap dikembangkan. JSON {"idea":"..."}.'}],z.object({idea:z.string().min(8)}));
   }else if(action==="recommend"){
    result=await callAI([common,{role:"user",content:`Pilih satu nama gaya visual PALING tepat dari katalog (atau sarankan custom) dan alasannya. JSON {"style":"...","why":"..."}. Konteks: ${describeSettings(p.settings!,presetModels)}`}],z.object({style:z.string(),why:z.string()}));
   }else if(action==="ideas"){
    result=await callAI([common,{role:"user",content:`Hasilkan TEPAT LIMA konsep cerita BERBEDA namun SEMUA menjaga ide inti. Perbedaan pada sudut pandang, hook, konflik/struktur dan payoff; tidak mengubah inti. Hook spesifik 3 detik pertama. engagement.score integer 1-10 adalah heuristik non-prediktif disertai alasan. JSON {"concepts":[{"title":"","hook":"","synopsis":"","conflict":"","arc":"","ending":"","emotion":"","engagement":{"score":1,"reason":""}}]} tepat 5 item. Pengaturan: ${describeSettings(p.settings!,presetModels)}`}],ideasSchema);
   }else if(action==="storyboard"){
    const v=p.settings!; const {target,entry,plan}=modelProfile(v,presetModels);
    const splits=v.durations.map(d=>shotDurations(d,entry.maxClipSeconds));
    const schema=storyboardSchema.refine(s=>s.scenes.length===v.sceneCount,{message:`Harus tepat ${v.sceneCount} scenes`}).refine(s=>s.scenes.every((s,i)=>s.duration===v.durations[i]),{message:"Durasi setiap scene harus tepat sesuai input"}).refine(s=>s.scenes.every((s,i)=>s.shots.length===splits[i].length&&s.shots.every((sh,j)=>sh.duration===splits[i][j])),{message:"Durasi/jumlah shot tidak valid"});
    result=await callAI([common,{role:"user",content:`Bangun storyboard lengkap dari KONSEP YANG SUDAH DIPILIH: ${JSON.stringify(p.concept)}. Pengaturan: ${describeSettings(v,presetModels)}. Buat characterBible dan styleBible terperinci serta masterPrompt BERBAHASA INGGRIS. Buat tepat ${v.sceneCount} scene, durasi berturut-turut ${JSON.stringify(v.durations)} detik. Setiap scene wajib berisi title, duration, goal, characters (nama karakter), location, action, visual, emotion, camera, framing, lighting, ambience, dialogue, sfx, transition, continuity, negativePrompt, prompt, shots:[{duration,prompt}]. Shot prompt bahasa Inggris, detail dan bisa digunakan terpisah. Pembagian shot per scene HARUS PERSIS ${JSON.stringify(splits)}. Jika scene memuat dua shot, buat prompt terpisah yang berkesinambungan dan tidak melewati batas ${entry.maxClipSeconds||"tidak diketahui"}s per klip. Setiap prompt scene spesifik visual, acting, kamera, audio, continuity; satu aksi utama dalam satu shot. Jangan mengarang kemampuan ${target} yang belum pasti. ${plan}. Dialog alami dan ringkas, jangan berlebihan. Catat konsistensi pakaian, properti, arah gerak dan lighting antar scene. Quality score 1-10 heuristik beserta alasan dan improvements. Kembalikan objek JSON {"characterBible":"","styleBible":"","masterPrompt":"","quality":{"score":8,"reasons":[""],"improvements":[""]},"scenes":[{...}]}.`}],schema,false,16000);
   }else if(action==="scene"){
    const v=p.settings!;const sceneIndex=p.sceneIndex!; const {entry}=modelProfile(v,presetModels);
    const split=shotDurations(v.durations[sceneIndex],entry.maxClipSeconds);
    const schema=z.object({scene:sceneSchema.refine(s=>s.duration===v.durations[sceneIndex]&&s.shots.length===split.length&&s.shots.every((x,i)=>x.duration===split[i]),{message:"Durasi regenerasi salah"})});
    result=await callAI([common,{role:"user",content:`REGENERATE HANYA scene nomor ${sceneIndex+1} dari storyboard tanpa mengubah scene lain. Kembalikan {"scene":{...}} dengan semua properti scene. Pertahankan continuity dengan scene sebelum dan sesudah. Pembagian shot harus ${JSON.stringify(split)}. Pengaturan ${describeSettings(v,presetModels)}. Konsep ${JSON.stringify(p.concept)}. Character Bible: ${p.storyboard!.characterBible}. Style Bible: ${p.storyboard!.styleBible}. Scene sebelumnya: ${JSON.stringify(p.storyboard!.scenes[sceneIndex-1]||null)}. Scene saat ini: ${JSON.stringify(p.storyboard!.scenes[sceneIndex])}. Scene berikut: ${JSON.stringify(p.storyboard!.scenes[sceneIndex+1]||null)}.`}],schema);
   }else if(action==="characters"){
    const content:Extract<AIMessage["content"],unknown[]>=[{type:"text",text:"Analisis masing-masing gambar karakter berurutan. Catat hanya ciri visual yang benar-benar tampak, bukan identitas nyata, umur tepat, etnis, atau atribut sensitif. Sertakan bentuk wajah, pakaian, aksesori, warna, bulu/rambut dan tanda khas. JSON {\"characters\":[{\"id\":\"...\",\"description\":\"...\"}]} tepat dalam urutan dan ID yang diberikan. Nama/ID: "+JSON.stringify(p.characters!.map(c=>({id:c.id,name:c.name,role:c.role})))}];
    for(const c of p.characters!){if(!c.path.startsWith(user.id+"/"))throw new Error("Path gambar bukan milik pengguna.");const signed=await db.storage.from("media-private").createSignedUrl(c.path,120);if(signed.error||!signed.data?.signedUrl)throw new Error("Gagal membaca gambar karakter.");content.push({type:"image_url",image_url:{url:signed.data.signedUrl,detail:"high"}});}
    result=await callAI([common,{role:"user",content}],z.object({characters:z.array(z.object({id:z.string(),description:z.string().min(10)})).length(p.characters!.length)}),true);
   }else{
    const content:Extract<AIMessage["content"],unknown[]>=[{type:"text",text:`Ini ANALISIS KEYFRAME, BUKAN ANALISIS SELURUH VIDEO. ${p.frames!.length} tangkapan gambar dipilih dari video ${p.atmDuration||"?"} detik. Jelaskan struktur, hook, pacing, transisi dan kamera secara INFERENSI dengan keterbatasan (tidak ada audio dan gerakan kontinu). Jangan mengklaim telah melihat seluruh video. Jangan salin dialog/karakter/identitas. Buat ringkasan teknik yang bisa dipakai untuk karya original. JSON wajib: {"summary":"","hook":"","storyStructure":"","pacing":"","transitions":"","framing":"","camera":"","tone":"","visualStyle":"","characters":"","originalityGuidance":"","limitations":""}. Catatan pengguna: ${p.analysisNotes||"tidak ada"}`}];
    for(const f of p.frames!)content.push({type:"image_url",image_url:{url:f,detail:"low"}});
    result=await callAI([common,{role:"user",content}],analysisSchema,true);
   }
   const input=result.usage.input,output=result.usage.output;
   const rIn=Number(process.env.AI_INPUT_USD_PER_1M),rOut=Number(process.env.AI_OUTPUT_USD_PER_1M);
   const cost=process.env.AI_INPUT_USD_PER_1M&&process.env.AI_OUTPUT_USD_PER_1M&&Number.isFinite(rIn)&&Number.isFinite(rOut)?Number(((input*rIn+output*rOut)/1000000).toFixed(6)):null;
   await db.rpc("finish_generation",{p_log:logId,p_success:true,p_input:input,p_output:output,p_cost:cost});
   return NextResponse.json({data:result.value,usage:{input,output,estimatedCostUSD:cost},notice:"AI menghasilkan prompt, bukan file video."});
  }catch(e){await db.rpc("finish_generation",{p_log:logId,p_success:false,p_error:e instanceof Error?e.message.slice(0,80):"unknown"});throw e;}
 }catch(e){const message=e instanceof Error?e.message:"Terjadi kesalahan server.";const status=message==="AUTH_REQUIRED"?401:message.includes("belum dikonfigurasi")?503:500;return err(message,status);}
}
