import { NextRequest,NextResponse } from "next/server";
import { authenticatedUser } from "@/lib/auth";
export const runtime="nodejs";
export async function DELETE(req:NextRequest){
 try{
  const {db,user}=await authenticatedUser(req);
  const body=await req.json().catch(()=>({}));
  if(body?.confirmation!=="HAPUS")return NextResponse.json({error:"Konfirmasi penghapusan akun tidak valid."},{status:400});
  // Delete owned media before deleting user. All media paths created by the app begin user.id/.
  const bucket=db.storage.from("media-private");
  for(let i=0;i<100;i++){
   const {data,error}=await bucket.list(user.id,{limit:100});
   if(error)throw new Error(`Gagal membaca file privat: ${error.message}`);
   if(!data?.length)break;
   const paths=data.filter(x=>x.name&&!x.name.startsWith(".")).map(x=>`${user.id}/${x.name}`);
   if(!paths.length)break;
   const removed=await bucket.remove(paths);
   if(removed.error)throw new Error(`Gagal menghapus media: ${removed.error.message}`);
   if(i===99)throw new Error("Masih ada banyak file. Hubungi admin untuk pembersihan lanjutan.");
  }
  const {error:authError}=await db.auth.admin.deleteUser(user.id);
  if(authError)throw new Error(`Gagal menghapus akun: ${authError.message}`);
  return NextResponse.json({ok:true});
 }catch(e){const message=e instanceof Error?e.message:"Gagal menghapus akun";return NextResponse.json({error:message},{status:message==="AUTH_REQUIRED"?401:500});}
}
