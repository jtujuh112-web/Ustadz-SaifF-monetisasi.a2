import Link from "next/link";
export default function Privacy() {
 return <main className="mx-auto max-w-3xl px-6 py-16 text-slate-100"><Link href="/" className="text-emerald-300">← Kembali ke studio</Link>
 <h1 className="mt-8 text-3xl font-bold">Informasi Privasi & Penggunaan</h1>
 <p className="mt-5 leading-8 text-slate-300">Ini adalah template kebijakan yang harus disesuaikan pemilik layanan sebelum dipublikasikan ke pengguna. Prompt, informasi akun, dan media yang diunggah diproses melalui Supabase serta penyedia AI yang dikonfigurasi operator. Jangan unggah materi pribadi atau karya pihak lain tanpa izin. Media disimpan di bucket privat dan dapat dihapus dari antarmuka.</p>
 <p className="mt-5 leading-8 text-slate-300">Penggunaan layanan penyedia AI tunduk pada kebijakan mereka. Pemilik aplikasi wajib menentukan masa retensi data, kontak pengelola, dasar pemrosesan, permintaan akses/penghapusan, dan pemberitahuan layanan pihak ketiga sebelum peluncuran publik.</p></main>
}
