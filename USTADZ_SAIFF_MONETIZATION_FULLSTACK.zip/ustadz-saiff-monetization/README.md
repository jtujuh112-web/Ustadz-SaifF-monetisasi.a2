# USTADZ SAIFF MONETIZATION

**Full-stack AI Video Prompt Generator** — Next.js 15 App Router, TypeScript, Tailwind CSS, Supabase (Auth + Postgres + private Storage), server-side OpenAI-compatible prompt/vision backend (official OpenAI Chat Completions implementation).

**Status:** source code disiapkan untuk deployment, **belum benar-benar dijalankan dengan dependensi terinstal**, **belum di-deploy**, dan **belum diuji memakai Supabase/OpenAI live**. Every AI request requires a real API connection. This project **generates prompts, not rendered video files**. There are no fake buttons to render video.

## 1. Arsitektur

```text
Android/iPhone/Desktop Browser
    │
    ├─ Next.js Studio (responsive, auth, uploads, storyboard, history, admin)
    │     └─ Supabase browser client → Auth + private Storage + RLS projects
    │
    └─ /api/ai (Authorization: Bearer Supabase access token)
          ├─ Supabase admin SDK → verify user + role + quota RPC
          ├─ /v1/chat/completions → AI text (5 ideas, storyboards)
          ├─ Vision API → character image via server-generated signed URLs
          ├─ Video ATM → four browser-extracted keyframes sent on consent
          ├─ Zod validation + retry on invalid provider JSON
          └─ Supabase generation_logs (tokens, status, optional cost)

    /api/admin → independent server-side admin role check
```

**Implementasi inti tersedia:**

- Premium dark/emerald/gold mobile UI dengan Arabic di bagian atas, dashboard, menu, auth, skeleton loading, error boundary, 404 dan toast.
- 29 kategori dan 32 gaya visual; katalog admin-editable (thumbnail adalah ilustrasi simbolik, bukan hasil AI yang telah dirender).
- Ide, custom instruksi, suasana, audiens, pesan, tujuan, kategori/style/custom, lokasi, waktu/cuaca/pencahayaan, audio/bahasa/custom, format dan model.
- Upload 1–10 gambar (atau lebih rendah bila admin mengatur), urut, peran, nama, pratinjau, pilih banyak yang aktif, hapus; Vision AI menganalisis ciri terlihat.
- Scene 1–20 dengan durasi editorial terpisah 10–15 detik dan total otomatis.
- AI menghasilkan **tepat lima** konsep yang divalidasi Zod; memilih/mengedit/menggabung dua ide atau menggunakan ide sendiri.
- Prompt scene terstruktur, master/character/style bible, storyboard, dialog, shot, metadata continuity, lock/edit/regenerate scene, copy, TXT, JSON dan PDF.
- Target model dengan batas durasi dan rencana shot, serta tanda verified/experimental/retired.
- ATM video: preview MP4/MOV/WebM (bergantung codec browser), metadata, upload privat, ekstraksi 4 frame lokal setelah persetujuan, analisis AI Vision terbatas terhadap frame, edit ringkasan, pilih teknik, dan lanjut ke 5 konsep original.
- Login / register Supabase, dashboard member, autosave proyek, riwayat, duplikasi, favorit, status plan dan kuota, tombol hapus akun/data permanen, dashboard admin, member management, katalog dan preset editing, API token logs.
- RLS profiles/projects/storage, quotas di Postgres RPC ber-lock, 5 generate/menit per user, server-only AI/DB privileged keys.

**Batasan yang ditandai eksplisit:**

- Untuk membuat file video asli, **belum ada adapter API render video aktif**. Semua model pada katalog `videoApi:false`; UI hanya mengekspor prompt teks (A), bukan file video (B). Tambahkan adapter provider resmi, async job queue, callback/poll dan pembayaran sebelum mengaktifkan B.
- Seedance 2.0 dan 2.5 resmi ada; tetapi API, paket dan parameter tidak otomatis tersedia. Veo 3.1 di beberapa layanan terbatas 4/6/8 detik, sehingga scene editorial yang lebih panjang dipecah ke dua shot. Sora API resmi dihentikan 24 September 2026.
- Gaya visual ditampilkan dengan ilustrasi simbolik, bukan sampel video hasil AI.
- ATM tidak melakukan full-video understanding, tidak mendeteksi suara / dialog secara langsung; kesimpulan gerak/pacing berbasis frame dan mengandung ketidakpastian.
- PDF memakai font standar jsPDF; karakter non-Latin tertentu mungkin hilang. TXT/JSON mempertahankan Unicode.
- Supabase Storage **memerlukan konfigurasi ukuran file** yang sesuai plan, dan batas max upload tersaji di UI. Bucket memiliki hard cap 50MB; untuk enforcement dinamis server-side per file sebaiknya gunakan signed-upload endpoint dengan pemeriksaan metadata dan cleanup.
- Tidak ada sistem pembayaran otomatis, email pemasaran, push notification, atau vendor billing.
- Admin settings menyimpan nama/aturan model, bukan otomatis mengintegrasikan API model tersebut. Set `status:"verified"` hanya setelah operator memverifikasi sumbernya.

## 2. Jalankan lokal

Perlu **Node.js 20.9+** (disarankan 22 LTS), npm, akun Supabase, dan API key OpenAI dengan tagihan API terpisah. Akun ChatGPT Plus tidak otomatis menyertakan kredit OpenAI API.

```bash
npm install
cp .env.example .env.local
# buka .env.local dan isi API keys dengan nilai Anda sendiri
npm run dev
```

Buka `http://localhost:3000`. Cek `http://localhost:3000/api/health` untuk status konfigurasi (tidak menampilkan key rahasia). Untuk production: `npm run test:source && npm run typecheck && npm run build`.

## 3. Setup Supabase

1. Buat project Supabase baru. Buka **Project Settings → API**. Salin **Project URL**, **anon/publishable key** yang cocok dengan `@supabase/supabase-js`, dan **service_role (secret)**. Jangan pernah masukkan service_role ke variabel `NEXT_PUBLIC_` atau browser.
2. Di **SQL Editor** jalankan seluruh `supabase/migrations/001_init.sql` sekali. SQL ini membuat `profiles`, `projects`, `generation_logs`, `app_settings`, role/RLS, trigger profil baru, quota RPC, private bucket dan policy file.
3. Di **Authentication → Providers → Email**, aktifkan email/password. Atur redirect URL/domain production. Untuk testing cepat email confirmation bisa disesuaikan dengan risiko, tetapi sebaiknya aktifkan saat produksi.
4. Di **Storage → media-private**, pastikan bucket privat dan limit file sesuai plan. RLS file memakai folder pertama = `auth.uid()`.
5. Daftar akun pertama melalui UI aplikasi. Setelah profil dibuat, jalankan SQL berikut pada SQL Editor sebagai admin project (ganti email):

```sql
update public.profiles
set role='admin', monthly_quota=100000
where email='EMAIL_ANDA@CONTOH.COM';
```

6. Refresh/keluar masuk akun. Menu **Admin** terlihat. Role tidak bisa diubah dari frontend. Admin dapat menonaktifkan member dan mengatur kuota.

**Catatan:** jika pengguna sudah terdaftar *sebelum* migrasi dibuat, Anda perlu membuat profil mereka secara terpisah. Jangan mengekspos role update dalam query client.

## 4. Setup AI

Isi di `.env.local`:

```dotenv
OPENAI_API_KEY=...     # DAPATKAN DARI PLATFORM OPENAI API
AI_TEXT_MODEL=gpt-4.1-mini
AI_VISION_MODEL=gpt-4.1-mini
```

Model AI ini digunakan untuk **analisis dan penulisan prompt**, bukan model video yang dipilih di UI. Preset Seedance/Veo hanya menentukan gaya instruksi dan pembagian shot. Model OpenAI dapat diganti lewat env jika mendukung endpoint Chat Completions dan JSON object mode. Pilihan model/provider lain memerlukan adapter di `src/lib/ai.ts`.

Untuk estimasi biaya admin (opsional), isi tarif **sesuai harga aktual di akun Anda**:

```dotenv
AI_INPUT_USD_PER_1M=...
AI_OUTPUT_USD_PER_1M=...
```

Jangan isi nilai contoh fiktif untuk pengambilan keputusan billing. Tanpa nilai tersebut, `estimated_cost_usd` kosong dan token tetap tercatat. Kuota dihitung per operasi AI yang berhasil (termasuk analisis, saran dan regenerasi) dan dikembalikan jika error provider ditangani.

## 5. Deploy Vercel dari HP Android — tanpa laptop

1. Buat akun **GitHub** di `https://github.com/signup` melalui Chrome Android. Buat repository **private**, mis. `ustadz-saiff-monetization`.
2. Ekstrak ZIP ini di HP (aplikasi Files/ZArchiver). Upload **semua isi folder proyek** ke repository melalui browser GitHub (mode desktop mungkin lebih mudah), atau gunakan aplikasi Git Android. Jangan upload file `.env.local`.
3. Buat akun **Vercel** di `https://vercel.com/signup` dengan login GitHub. Klik **Add New → Project**, pilih repo tersebut.
4. Framework **Next.js** (auto-detected). Pada **Environment Variables**, isi `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `OPENAI_API_KEY`, `AI_TEXT_MODEL`, `AI_VISION_MODEL` sesuai nilai Anda. Pastikan key rahasia **tidak** diawali NEXT_PUBLIC.
5. Klik **Deploy**. Jika build gagal, buka log. Setelah deploy dapat alamat `<nama>.vercel.app` (alamat nyata hanya diberikan oleh Vercel saat deploy).
6. Kembali ke Supabase Authentication → URL Configuration. Atur Site URL dan Redirect URLs untuk domain Vercel yang sesungguhnya.
7. Daftar akun, angkat jadi admin lewat SQL Editor, login ulang, uji alur penuh. Pastikan akun Supabase dan OpenAI memiliki kuota/billing yang memadai.
8. Sebelum memberikan akses ke member umum: sesuaikan halaman `/privasi`, ketentuan layanan, tarif/paket, retensi data, penghapusan media dan batas biaya, jalankan uji keamanan/monitoring, lalu tambahkan domain khusus bila perlu.

### Cara upload repo dari HP (jika GitHub web tidak menerima folder)

GitHub Web → repository → **Add file → Upload files**; upload file di akar repo terlebih dahulu. Untuk subfolder, GitHub web tidak selalu mempermudah upload banyak folder bersarang. Cara alternatif gunakan **github.dev** di browser (tekan titik `.` pada halaman repo saat keyboard aktif), atau **Termux** untuk `git add/commit/push` jika sudah familier. Pastikan struktur `src/app/...` dan `supabase/migrations/...` tetap utuh.

## 6. Test manual end-to-end

- [ ] `/api/health` menunjukkan Supabase dan AI sudah dikonfigurasi.
- [ ] Registrasi, verifikasi email bila dipakai, login/logout.
- [ ] Upload PNG/JPG/WEBP, urut dan peran karakter, analisis visual, hapus file.
- [ ] Isi ide 8+ karakter, scene 1–20, durasi 10–15, ganti model, cek total.
- [ ] Generate konsep → **harus tepat 5**; edit/pilih/gabung; buat storyboard → semua scene punya durasi tepat, prompt Inggris, shot yang dibagi jika Veo.
- [ ] Lock scene pertama lalu regenerate scene lain; scene terkunci tidak berubah.
- [ ] Copy, TXT, JSON, PDF; periksa penggunaan bahasa dan continuity.
- [ ] Autosave, buka Riwayat, Favorit, Duplikat, Hapus.
- [ ] ATM: pilih video kompatibel; periksa metadata; setujui; analisis keyframe; ubah ringkasan; buat 5 konsep baru.
- [ ] Admin: nonaktifkan member; periksa diblokir pada `/api/ai`; atur kuota, katalog, limit; cek log token dan status.
- [ ] Coba tanpa API key, tanpa token, file terlalu besar, kuota habis, 6 request/menit; semua harus memberi error, bukan output palsu.

## 7. Struktur file

```text
src/app/page.tsx                 halaman Studio
src/components/Studio.tsx       dashboard, generator, ATM, riwayat, favorit, admin, akun
src/app/api/ai/route.ts         backend AI, kuota, vision, schema
src/app/api/admin/route.ts      admin operations (server role check)
src/app/api/account/route.ts    penghapusan akun dan media privat
src/app/api/health/route.ts     status konfigurasi
src/lib/ai.ts                   AI adapter, template, target shot plan
src/lib/schemas.ts              validasi input, 5 ide, scene/storyboard
src/lib/catalog.ts              kategori, visual, lokasi, preset models
src/lib/supabase-browser.ts     Supabase browser client
src/lib/auth.ts                 bearer verification service-side
src/lib/export.ts               TXT, JSON, PDF
src/app/privasi/page.tsx        template privasi
src/app/loading.tsx              loading skeleton
src/app/error.tsx                error boundary
src/lib/validator.ts             pemeriksaan otomatis scene/durasi
supabase/migrations/001_init.sql skema + RLS + quota/storage
```

## 8. Status pemeriksaan dalam sesi pembuatan

Pemeriksaan sumber `tests/source-smoke.cjs`: **LULUS** pada 18 file TypeScript/TSX, termasuk 5 skenario pembagian shot dan pembacaan batas model. Pemeriksaan ini hanya memastikan sintaks dapat ditranspilasi dan beberapa fungsi deterministik benar. **Build `next build`, akses database nyata, pengujian browser Android, biaya API, dan pengujian keamanan belum dilakukan** karena instalasi dependensi npm / kredensial layanan belum tersedia di lingkungan pembuatan. Lanjutkan checklist pada `docs/MANUAL_TESTS.md` sesudah konfigurasi.

## 9. Peringatan operasional

Website ini memproses data menggunakan jasa pihak ketiga (Supabase & OpenAI). Biaya dan ketentuan provider terpisah. Setelah banyak pengguna, pertimbangkan: background job queue, idempotency key, pembatasan token per request, logging sanitization, request budget, upload scanning, data retention/deletion workflow, monitoring abuse, CSP, captcha, testing dengan browser sungguhan, output content moderation, observability, dan backup DB. Sebelum produksi gunakan API per-user quota dan database production.

## Sumber referensi model (terverifikasi per Nov 2026)

- Seedance 2.0 (ByteDance resmi): https://seed.bytedance.com/en/blog/seedance-2-0-official-launch
- Seedance 2.5 (ByteDance resmi): https://seed.bytedance.com/en/blog/one-take-creation-flexible-referencing-introducing-seedance-2-5
- Veo 3.1 Google Cloud: https://docs.cloud.google.com/gemini-enterprise-agent-platform/models/veo/3-1-generate.md
- Sora API deprecated (OpenAI): https://developers.openai.com/api/docs/deprecations
- Muse Video API: https://muse-video.com/docs (Muse AI disetel eksperimental sampai model/pemilik layanan dipastikan)
