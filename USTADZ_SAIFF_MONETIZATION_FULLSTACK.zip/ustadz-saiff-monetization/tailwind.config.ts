import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        midnight: "#071412", spruce: "#0D2924", emeraldx: "#1BA980", goldx: "#D8B56C", mutedx: "#A0B6B0"
      },
      fontFamily: { sans: ["Inter", "Arial", "sans-serif"], arabic: ["Amiri", "Noto Naskh Arabic", "serif"] },
      boxShadow: { glow: "0 12px 50px rgba(14,179,130,.17)", gold: "0 10px 35px rgba(216,181,108,.1)" },
      animation: { float: "float 6s ease-in-out infinite", rise: "rise .45s ease both" },
      keyframes: {
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-7px)" } },
        rise: { "0%": { opacity: "0", transform: "translateY(9px)" }, "100%": { opacity: "1", transform: "translateY(0)" } }
      }
    }
  }, plugins: []
} satisfies Config;
