-- Jalankan sekali pada Supabase SQL Editor. Jangan jalankan dengan kredensial browser.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 email text, display_name text,
 role text not null default 'member' check (role in ('admin','member')),
 membership text not null default 'active' check (membership in ('active','suspended')),
 plan text not null default 'starter',
 monthly_quota int not null default 20 check (monthly_quota between 0 and 100000),
 quota_used int not null default 0,
 quota_month date not null default date_trunc('month', now())::date,
 created_at timestamptz not null default now()
);
create table if not exists public.projects (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 title text not null default 'Proyek baru',
 source text not null default 'studio' check(source in ('studio','atm')),
 settings jsonb not null default '{}'::jsonb,
 concepts jsonb not null default '[]'::jsonb,
 selected_concept jsonb,
 storyboard jsonb,
 character_bible text,
 is_favorite boolean not null default false,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index if not exists projects_user_updated on public.projects(user_id,updated_at desc);
create table if not exists public.generation_logs (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 operation text not null,
 provider text not null default 'openai',
 model text,
 status text not null default 'started' check(status in ('started','success','failed')),
 input_tokens integer,
 output_tokens integer,
 estimated_cost_usd numeric(12,6),
 error_code text,
 created_at timestamptz not null default now(),
 finished_at timestamptz
);
create index if not exists logs_user_time on public.generation_logs(user_id,created_at desc);
create table if not exists public.app_settings (
 id text primary key default 'global' check(id='global'),
 data jsonb not null default '{}'::jsonb,
 updated_at timestamptz not null default now()
);
insert into public.app_settings(id,data) values('global','{}'::jsonb) on conflict (id) do nothing;
create or replace function public.current_user_is_admin() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;
revoke all on function public.current_user_is_admin() from public;
grant execute on function public.current_user_is_admin() to authenticated;

alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.generation_logs enable row level security;
alter table public.app_settings enable row level security;
create policy "profile self or admin read" on public.profiles for select to authenticated using(id=auth.uid() or public.current_user_is_admin());
-- Role, quota dan status hanya boleh diubah melalui server service_role.
create policy "project select own" on public.projects for select to authenticated using(user_id=auth.uid());
create policy "project insert own" on public.projects for insert to authenticated with check(user_id=auth.uid());
create policy "project update own" on public.projects for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "project delete own" on public.projects for delete to authenticated using(user_id=auth.uid());
create policy "logs own or admin read" on public.generation_logs for select to authenticated using(user_id=auth.uid() or public.current_user_is_admin());
create policy "settings read" on public.app_settings for select to authenticated using(true);
-- Settings hanya diubah lewat /api/admin, bukan langsung browser.

create or replace function public.on_auth_user_created() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,email,display_name) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'display_name',split_part(new.email,'@',1))) on conflict(id) do nothing;
 return new;
end;$$;
drop trigger if exists after_auth_signup on auth.users;
create trigger after_auth_signup after insert on auth.users for each row execute function public.on_auth_user_created();

create or replace function public.claim_generation(p_user uuid,p_operation text,p_model text) returns uuid
language plpgsql security definer set search_path=public as $$
declare p public.profiles%rowtype; log_id uuid; recent_count int;
begin
 if auth.role() <> 'service_role' then raise exception 'server_only'; end if;
 select * into p from public.profiles where id=p_user for update;
 if not found then raise exception 'profile_not_found'; end if;
 if p.membership<>'active' then raise exception 'membership_inactive'; end if;
 if p.quota_month<>date_trunc('month',now())::date then
  update public.profiles set quota_month=date_trunc('month',now())::date,quota_used=0 where id=p_user;
  p.quota_used:=0;
 end if;
 select count(*) into recent_count from public.generation_logs where user_id=p_user and created_at>now()-interval '1 minute';
 if recent_count >= 5 then raise exception 'rate_limited'; end if;
 if p.role<>'admin' and p.quota_used>=p.monthly_quota then raise exception 'quota_exceeded'; end if;
 update public.profiles set quota_used=quota_used+1 where id=p_user;
 insert into public.generation_logs(user_id,operation,model) values(p_user,p_operation,p_model) returning id into log_id;
 return log_id;
end;$$;
revoke all on function public.claim_generation(uuid,text,text) from public,anon,authenticated;
grant execute on function public.claim_generation(uuid,text,text) to service_role;

create or replace function public.finish_generation(p_log uuid,p_success boolean,p_input int default null,p_output int default null,p_cost numeric default null,p_error text default null) returns void
language plpgsql security definer set search_path=public as $$
declare v_user uuid;
begin
 if auth.role()<>'service_role' then raise exception 'server_only'; end if;
 update public.generation_logs set status=case when p_success then 'success' else 'failed' end,
  input_tokens=p_input,output_tokens=p_output,estimated_cost_usd=p_cost,error_code=left(p_error,100),finished_at=now()
  where id=p_log and status='started' returning user_id into v_user;
 if found and not p_success then update public.profiles set quota_used=greatest(0,quota_used-1) where id=v_user; end if;
end;$$;
revoke all on function public.finish_generation(uuid,boolean,int,int,numeric,text) from public,anon,authenticated;
grant execute on function public.finish_generation(uuid,boolean,int,int,numeric,text) to service_role;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('media-private','media-private',false,52428800,ARRAY['image/jpeg','image/png','image/webp','video/mp4','video/quicktime','video/webm'])
on conflict(id) do update set public=false,file_size_limit=52428800,allowed_mime_types=excluded.allowed_mime_types;
create policy "private media select owner" on storage.objects for select to authenticated using(bucket_id='media-private' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "private media insert owner" on storage.objects for insert to authenticated with check(bucket_id='media-private' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "private media delete owner" on storage.objects for delete to authenticated using(bucket_id='media-private' and (storage.foldername(name))[1]=auth.uid()::text);

-- SETELAH registrasi akun pertama: admin via SQL Editor saja (ganti email):
-- update public.profiles set role='admin',monthly_quota=100000 where email='email-admin-anda@example.com';
