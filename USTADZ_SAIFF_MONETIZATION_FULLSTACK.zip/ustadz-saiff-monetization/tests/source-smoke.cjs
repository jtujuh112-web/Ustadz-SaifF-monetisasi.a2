/** Lightweight source & deterministic engine tests; run: npm run test:source */
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const assert=require('node:assert/strict');
const ts=require('typescript');const root=path.resolve(__dirname,'..');
const srcFiles=[];
function walk(dir){for(const node of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,node.name);if(node.isDirectory())walk(f);else if(/\.tsx?$/.test(node.name))srcFiles.push(f);}}
walk(path.join(root,'src'));
for(const f of srcFiles){const source=fs.readFileSync(f,'utf8');const out=ts.transpileModule(source,{fileName:f,reportDiagnostics:true,compilerOptions:{jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}});assert.equal((out.diagnostics||[]).length,0,`Transpile failed: ${f}`);}
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'saiff-smoke-'));
try{
 for(const f of ['catalog.ts','ai.ts']){
  const original=fs.readFileSync(path.join(root,'src','lib',f),'utf8');const js=ts.transpileModule(original,{fileName:f,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;
  fs.writeFileSync(path.join(dir,f.replace('.ts','.js')),js);
 }
 const {shotDurations,modelProfile}=require(path.join(dir,'ai.js'));
 assert.deepEqual(shotDurations(10,8),[5,5]);
 assert.deepEqual(shotDurations(12,8),[6,6]);
 assert.deepEqual(shotDurations(15,8),[8,7]);
 assert.deepEqual(shotDurations(15,15),[15]);
 assert.deepEqual(shotDurations(12,null),[12]);
 assert.match(modelProfile({modelId:'veo-31',durations:[12],aspect:'9:16'}).plan,/8 detik/);
 assert.equal(modelProfile({modelId:'seedance-2',durations:[12],aspect:'9:16'}).plan,'');
 console.log(`PASS: ${srcFiles.length} TS/TSX files transpile; deterministic shot/constraint checks pass.`);
}finally{fs.rmSync(dir,{recursive:true,force:true});}
